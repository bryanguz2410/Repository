#!/usr/bin/env python3
import sys
import os

# Agregar el directorio actual al path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

try:
    # Importar la aplicación Flask
    from __init__ import app as application
    print("✅ Aplicación PMML genérica cargada desde __init__.py")
except ImportError as e:
    print(f"❌ Error importando aplicación: {e}")
    
    # Crear aplicación mínima de emergencia
    try:
        from flask import Flask
        application = Flask(__name__)
        
        @application.route('/')
        def error():
            return '''
            <!DOCTYPE html>
            <html>
            <head>
                <title>Error - Predictor PMML</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
                    .error { background: #fee; border: 2px solid #fcc; padding: 25px; border-radius: 8px; max-width: 600px; }
                    h1 { color: #c33; margin-bottom: 15px; }
                    .info { background: #e3f2fd; border: 1px solid #2196f3; padding: 15px; border-radius: 6px; margin-top: 20px; }
                    .commands { background: #f8f9fa; border: 1px solid #dee2e6; padding: 15px; border-radius: 6px; margin-top: 15px; font-family: monospace; }
                </style>
            </head>
            <body>
                <div class="error">
                    <h1>⚠️ Error de Configuración</h1>
                    <p><strong>No se pudo cargar la aplicación PMML.</strong></p>
                    
                    <div class="info">
                        <h3>📋 Archivos necesarios:</h3>
                        <ul>
                            <li>__init__.py (aplicación principal)</li>
                            <li>templates/pmml_generico.html (interface)</li>
                            <li>*.pmml (archivos de modelo)</li>
                        </ul>
                    </div>
                    
                    <div class="info">
                        <h3>🔧 Dependencias opcionales:</h3>
                        <div class="commands">
                            pip install pypmml  # Requiere Java
                        </div>
                        <p><em>Sin pypmml, el sistema usará parsing XML manual</em></p>
                    </div>
                    
                    <div class="info">
                        <h3>📁 Estructura esperada:</h3>
                        <div class="commands">
~/www/<br>
├── __init__.py<br>
├── passenger_wsgi.py<br>
├── templates/<br>
│   └── pmml_generico.html<br>
└── *.pmml (tus modelos)
                        </div>
                    </div>
                </div>
            </body>
            </html>
            '''
        
        print("✅ Aplicación de emergencia creada")
        
    except Exception as e2:
        print(f"❌ Error crítico creando fallback: {e2}")
        
        # Último recurso: función WSGI básica
        def application(environ, start_response):
            status = '500 Internal Server Error'
            headers = [('Content-type', 'text/plain; charset=utf-8')]
            start_response(status, headers)
            error_msg = f"Error crítico en passenger_wsgi.py:\n{e}\n{e2}"
            return [error_msg.encode('utf-8')]

if __name__ == "__main__":
    # Solo para pruebas locales
    try:
        print("🧪 Modo de prueba local")
        application.run(debug=True, port=9000)
    except:
        print("❌ Error ejecutando en modo de prueba")