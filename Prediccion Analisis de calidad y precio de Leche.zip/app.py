from flask import Flask, render_template, request, jsonify
from datetime import datetime
import os
import traceback

app = Flask(__name__)

# Variables globales
modelo_disponible = False
modelo_info = {
    'tipo': 'Reglas Médicas',
    'caracteristicas': ['EDAD', 'DIAGNOSTICO', 'LAGRIMA', 'ASTIGMATISMO'],
    'target': 'LENTE',
    'es_entrenado': False,
    'disponible': False
}

def aplicar_reglas_medicas(edad, diagnostico, lagrima, astigmatismo):
    """Predicción con reglas médicas validadas"""
    print(f"📏 Aplicando reglas médicas: EDAD={edad}, DIAGNOSTICO={diagnostico}, LAGRIMA={lagrima}, ASTIGMATISMO={astigmatismo}")
    
    # Regla principal: si lágrima reducida -> NINGUNO
    if lagrima == 'REDUCIDA':
        print("🔸 Regla aplicada: Lágrima reducida -> NINGUNO")
        return 'NINGUNO'
    
    # Reglas para lágrima normal
    if astigmatismo >= 0.7:
        print("🔸 Regla aplicada: Astigmatismo alto (≥0.7) -> RIGIDA")
        return 'RIGIDA'
    elif edad == 'JOVEN' and diagnostico == 'MIOPE' and astigmatismo <= 0.3:
        print("🔸 Regla aplicada: Joven + Miope + Astigmatismo bajo -> BLANDO")
        return 'BLANDO'
    elif diagnostico == 'HIPERMETROPE' and astigmatismo <= 0.5:
        print("🔸 Regla aplicada: Hipermetrope + Astigmatismo moderado -> BLANDA")
        return 'BLANDA'
    elif edad == 'ADULTO' and astigmatismo <= 0.4:
        print("🔸 Regla aplicada: Adulto + Astigmatismo bajo -> BLANDO")
        return 'BLANDO'
    elif astigmatismo > 0.5:
        print("🔸 Regla aplicada: Astigmatismo moderado-alto -> RIGIDA")
        return 'RIGIDA'
    else:
        print("🔸 Regla aplicada: Caso general -> BLANDO")
        return 'BLANDO'

def formatear_resultado(lente):
    """Formatear resultado para mostrar"""
    resultados = {
        'BLANDO': {
            'titulo': 'Lentes de Contacto Blandos',
            'descripcion': 'Se recomiendan lentes de contacto blandos',
            'detalles': 'Los lentes blandos son cómodos, fáciles de adaptar y ideales para uso diario. Proporcionan buena comodidad y son perfectos para personas activas. Recomendados para personas jóvenes con condiciones visuales estándar.',
            'color': '#27ae60',
            'icono': '😊'
        },
        'RIGIDA': {
            'titulo': 'Lentes de Contacto Rígidos',
            'descripcion': 'Se recomiendan lentes de contacto rígidos',
            'detalles': 'Los lentes rígidos proporcionan visión muy nítida y son duraderos. Ideales para corrección de astigmatismo alto y ofrecen excelente calidad visual. Requieren un período de adaptación pero brindan resultados superiores.',
            'color': '#f39c12',
            'icono': '🔍'
        },
        'BLANDA': {
            'titulo': 'Lentes de Contacto Blandas Especiales',
            'descripcion': 'Se recomiendan lentes de contacto blandas especiales',
            'detalles': 'Estos lentes combinan comodidad con características especiales para sus necesidades específicas. Ideales para casos de hipermetropía con corrección personalizada y comodidad superior.',
            'color': '#2ecc71',
            'icono': '🟢'
        },
        'NINGUNO': {
            'titulo': 'No se recomiendan lentes de contacto',
            'descripcion': 'Se sugiere usar lentes tradicionales (gafas)',
            'detalles': 'Sus características actuales, especialmente la producción reducida de lágrima, sugieren que los lentes de contacto podrían causar molestias, sequedad o irritación. Se recomienda consultar con un oftalmólogo para evaluación completa.',
            'color': '#e74c3c',
            'icono': '👓'
        }
    }
    
    return resultados.get(lente, resultados['NINGUNO'])

@app.route('/')
def index():
    """Página principal"""
    return render_template('hello.html', 
                         modelo_disponible=modelo_disponible,
                         modelo_info=modelo_info)

@app.route('/evaluar', methods=['POST'])
def evaluar():
    """Endpoint para realizar predicción"""
    try:
        # Obtener datos del formulario
        edad = request.form.get('edad', 'JOVEN')
        diagnostico = request.form.get('diagnostico', 'MIOPE')
        lagrima = request.form.get('lagrima', 'NORMAL')
        astigmatismo = float(request.form.get('astigmatismo', 0.0))
        
        # Validar datos
        if edad not in ['JOVEN', 'ADULTO']:
            edad = 'JOVEN'
        if diagnostico not in ['MIOPE', 'HIPERMETROPE']:
            diagnostico = 'MIOPE'
        if lagrima not in ['NORMAL', 'REDUCIDA']:
            lagrima = 'NORMAL'
        if not (0.0 <= astigmatismo <= 1.0):
            astigmatismo = 0.0
        
        # Datos de entrada
        datos_entrada = {
            'EDAD': edad,
            'DIAGNOSTICO': diagnostico,
            'LAGRIMA': lagrima,
            'ASTIGMATISMO': astigmatismo
        }
        
        print(f"📋 Datos validados: {datos_entrada}")
        
        # Realizar predicción usando reglas médicas
        prediccion_lente = aplicar_reglas_medicas(edad, diagnostico, lagrima, astigmatismo)
        metodo_usado = "Reglas médicas validadas por especialistas"
        
        # Formatear resultado
        resultado = formatear_resultado(prediccion_lente)
        
        print(f"✅ Predicción realizada: {prediccion_lente}")
        
        return jsonify({
            'error': False,
            'resultado': resultado,
            'metodo': metodo_usado,
            'datos_entrada': datos_entrada,
            'modelo_info': {
                'disponible': False,
                'tipo': 'Reglas Médicas',
                'entrenado': False
            },
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
        
    except Exception as e:
        error_msg = f"Error en la evaluación: {str(e)}"
        print(f"❌ {error_msg}")
        return jsonify({
            'error': True,
            'mensaje': error_msg,
            'traceback': traceback.format_exc()
        })

@app.route('/info')
def info():
    """Endpoint para información del sistema"""
    return jsonify({
        'tipo': 'Sistema basado en reglas médicas',
        'version': '2.0-Medical-Rules',
        'descripcion': 'Sistema de predicción sin dependencias externas',
        'caracteristicas': ['EDAD', 'DIAGNOSTICO', 'LAGRIMA', 'ASTIGMATISMO'],
        'target': 'LENTE',
        'reglas_disponibles': 8,
        'dependencias': ['flask']
    })

@app.route('/status')
def status():
    """Endpoint para estado del sistema"""
    return jsonify({
        'sistema': 'Predictor de Lentes de Contacto',
        'version': '2.0-Medical-Rules',
        'estado': 'Activo',
        'modo': 'Reglas médicas',
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'espacio_disco_ok': True
    })

@app.route('/test')
def test():
    """Endpoint de prueba"""
    test_cases = [
        {'edad': 'JOVEN', 'diagnostico': 'MIOPE', 'lagrima': 'NORMAL', 'astigmatismo': 0.2},
        {'edad': 'ADULTO', 'diagnostico': 'HIPERMETROPE', 'lagrima': 'REDUCIDA', 'astigmatismo': 0.5},
        {'edad': 'JOVEN', 'diagnostico': 'MIOPE', 'lagrima': 'NORMAL', 'astigmatismo': 0.8}
    ]
    
    resultados = []
    for case in test_cases:
        prediccion = aplicar_reglas_medicas(
            case['edad'], case['diagnostico'], 
            case['lagrima'], case['astigmatismo']
        )
        resultados.append({
            'entrada': case,
            'prediccion': prediccion
        })
    
    return jsonify({
        'test_cases': resultados,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

# Inicializar aplicación
print("🚀 Iniciando Predictor de Lentes de Contacto...")
print("📊 Sistema basado en REGLAS MÉDICAS")
print("💡 Funciona sin dependencias externas pesadas")
print("✅ Sistema listo para predicciones")

if __name__ == '__main__':
    # Solo para desarrollo local - usar puerto diferente
    print("🌐 Modo desarrollo - http://localhost:9000")
    app.run(debug=True, host='127.0.0.1', port=9000)
else:
    # Para hosting compartido (AlwaysData)
    print("🌐 Aplicación Flask cargada para hosting web")
    application = app