from flask import Flask, render_template, request, jsonify, redirect, url_for
import xml.etree.ElementTree as ET
from datetime import datetime
import os
import traceback

# Crear la aplicación Flask
app = Flask(__name__)

# Variables globales
pmml_cargado = False
modelo_info = {}
campos_entrada = {}
campo_target = ""
archivo_pmml = ""
arbol_decision = None

# Namespace PMML común
PMML_NAMESPACE = {
    'pmml': 'http://www.dmg.org/PMML-4_2',
    'pmml41': 'http://www.dmg.org/PMML-4_1',
    'pmml40': 'http://www.dmg.org/PMML-4_0',
    'pmml43': 'http://www.dmg.org/PMML-4_3',
    'pmml44': 'http://www.dmg.org/PMML-4_4'
}

# Intentar importar pypmml
try:
    from pypmml import Model as PMMLModel
    PYPMML_DISPONIBLE = True
    modelo_pypmml = None
    print("✅ pypmml disponible")
except ImportError:
    PYPMML_DISPONIBLE = False
    modelo_pypmml = None
    print("⚠️ pypmml no disponible - usando parsing XML manual")

def buscar_archivos_pmml():
    """Buscar archivos PMML en el directorio"""
    archivos = []
    for archivo in os.listdir('.'):
        if archivo.endswith('.pmml') or archivo.endswith('.xml'):
            archivos.append(archivo)
    return archivos

def detectar_namespace(root):
    """Detectar el namespace correcto del PMML"""
    if root.tag.startswith("{"):
        namespace = root.tag.split("}")[0].strip("{")
        print(f"🔍 Namespace extraído del tag raíz: {namespace}")
        return namespace
    
    for attr, value in root.attrib.items():
        if attr == 'xmlns':
            print(f"🔍 Namespace desde xmlns: {value}")
            return value
        elif attr.startswith('xmlns:') and 'pmml' in attr.lower():
            print(f"🔍 Namespace desde {attr}: {value}")
            return value
    
    for prefix, ns in PMML_NAMESPACE.items():
        if root.find(f'.//{{{ns}}}DataDictionary') is not None:
            print(f"🔍 Namespace detectado por prueba: {ns}")
            return ns
    
    print("🔍 Sin namespace detectado")
    return ''

def buscar_elemento_flexible(parent, elemento, namespace=''):
    """Buscar elementos con flexibilidad de namespace"""
    if namespace:
        xpath = f".//{{{namespace}}}{elemento}"
        resultado = parent.findall(xpath)
        if resultado:
            return resultado
    
    xpath = f".//{elemento}"
    resultado = parent.findall(xpath)
    if resultado:
        return resultado
    
    def buscar_recursivo(elem, tag_objetivo):
        encontrados = []
        tag_local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        
        if tag_local == tag_objetivo:
            encontrados.append(elem)
        
        for hijo in elem:
            encontrados.extend(buscar_recursivo(hijo, tag_objetivo))
        
        return encontrados
    
    return buscar_recursivo(parent, elemento)

def detectar_campo_target(root, namespace=''):
    """Detectar el campo target del modelo PMML"""
    print("🔍 Detectando campo target...")
    
    # Método 1: MiningSchema con usageType
    mining_schemas = buscar_elemento_flexible(root, 'MiningSchema', namespace)
    if mining_schemas:
        mining_fields = buscar_elemento_flexible(mining_schemas[0], 'MiningField', namespace)
        for field in mining_fields:
            usage = field.get('usageType', '')
            name = field.get('name', '')
            print(f"   📝 MiningField: {name} - Uso: {usage}")
            if usage in ['target', 'predicted'] and name:
                print(f"🎯 Target desde MiningSchema: {name}")
                return name
    
    # Método 2: Output del modelo
    tipos_modelo = ['TreeModel', 'RegressionModel', 'NeuralNetwork', 'SupportVectorMachineModel']
    for tipo_modelo in tipos_modelo:
        modelos = buscar_elemento_flexible(root, tipo_modelo, namespace)
        if modelos:
            outputs = buscar_elemento_flexible(modelos[0], 'Output', namespace)
            if outputs:
                output_fields = buscar_elemento_flexible(outputs[0], 'OutputField', namespace)
                for field in output_fields:
                    name = field.get('name', '')
                    feature = field.get('feature', '')
                    target_field = field.get('targetField', '')
                    print(f"   📝 OutputField: {name} - Feature: {feature} - TargetField: {target_field}")
                    
                    if target_field:
                        print(f"🎯 Target desde OutputField.targetField: {target_field}")
                        return target_field
                    elif feature in ['predictedValue', 'prediction'] and name:
                        print(f"🎯 Target desde OutputField.name: {name}")
                        return name
    
    # Método 3: Analizar estructura del árbol de decisión
    tree_models = buscar_elemento_flexible(root, 'TreeModel', namespace)
    if tree_models:
        nodes = buscar_elemento_flexible(tree_models[0], 'Node', namespace)
        if nodes:
            # Buscar nodos hoja con score
            for node in nodes:
                score = node.get('score')
                if score and score in campos_entrada:
                    # Verificar si este campo tiene las categorías que aparecen en los scores
                    categorias = campos_entrada[score].get('categorias', [])
                    scores_encontrados = set()
                    for n in nodes:
                        s = n.get('score')
                        if s:
                            scores_encontrados.add(s)
                    
                    # Si los scores coinciden con las categorías, es el target
                    if scores_encontrados and scores_encontrados.issubset(set(categorias)):
                        print(f"🎯 Target desde análisis de árbol: {score}")
                        return score
    
    print("❌ No se pudo detectar campo target")
    return ""

def extraer_estructura_arbol(root, namespace=''):
    """Extraer la estructura del árbol de decisión para predicciones"""
    global arbol_decision
    
    print("🌳 Extrayendo estructura del árbol...")
    tree_models = buscar_elemento_flexible(root, 'TreeModel', namespace)
    if not tree_models:
        print("❌ No se encontró TreeModel")
        return None
    
    def procesar_nodo(node_elem):
        """Procesar un nodo del árbol recursivamente"""
        nodo = {
            'id': node_elem.get('id', ''),
            'score': node_elem.get('score', ''),
            'recordCount': node_elem.get('recordCount', '0'),
            'condicion': None,
            'hijos': []
        }
        
        # Extraer predicado/condición
        predicates = ['SimplePredicate', 'CompoundPredicate', 'True', 'False']
        for pred_type in predicates:
            pred_elem = buscar_elemento_flexible(node_elem, pred_type, namespace)
            if pred_elem:
                pred = pred_elem[0]
                if pred_type == 'SimplePredicate':
                    nodo['condicion'] = {
                        'tipo': 'simple',
                        'campo': pred.get('field', ''),
                        'operador': pred.get('operator', ''),
                        'valor': pred.get('value', '')
                    }
                elif pred_type == 'True':
                    nodo['condicion'] = {'tipo': 'true'}
                break
        
        # Procesar nodos hijos
        child_nodes = []
        for child in node_elem:
            if child.tag.split('}')[-1] == 'Node':
                child_nodes.append(child)
        
        for child_node in child_nodes:
            nodo['hijos'].append(procesar_nodo(child_node))
        
        return nodo
    
    # Encontrar el nodo raíz
    root_node = buscar_elemento_flexible(tree_models[0], 'Node', namespace)
    if root_node:
        arbol_decision = procesar_nodo(root_node[0])
        print(f"✅ Árbol extraído con {len(root_node)} nodos")
        return arbol_decision
    
    return None

def predecir_con_arbol(datos_entrada, nodo=None):
    """Realizar predicción usando el árbol de decisión extraído"""
    if not arbol_decision:
        return None
    
    if nodo is None:
        nodo = arbol_decision
    
    # Si es un nodo hoja (sin hijos), devolver el score
    if not nodo['hijos']:
        return nodo['score']
    
    # Evaluar la condición y seguir por el hijo correspondiente
    for hijo in nodo['hijos']:
        if evaluar_condicion(hijo['condicion'], datos_entrada):
            return predecir_con_arbol(datos_entrada, hijo)
    
    # Si no se cumple ninguna condición, devolver el score del nodo actual
    return nodo['score']

def evaluar_condicion(condicion, datos):
    """Evaluar una condición del árbol"""
    if not condicion:
        return True
    
    if condicion.get('tipo') == 'true':
        return True
    
    if condicion.get('tipo') == 'simple':
        campo = condicion['campo']
        operador = condicion['operador']
        valor_condicion = condicion['valor']
        
        if campo not in datos:
            return False
        
        valor_dato = datos[campo]
        
        # Convertir valores para comparación
        try:
            if operador in ['lessThan', 'lessOrEqual', 'greaterThan', 'greaterOrEqual']:
                valor_condicion = float(valor_condicion)
                valor_dato = float(valor_dato)
            else:
                valor_condicion = str(valor_condicion)
                valor_dato = str(valor_dato)
        except ValueError:
            return False
        
        # Evaluar operador
        if operador == 'equal':
            return valor_dato == valor_condicion
        elif operador == 'notEqual':
            return valor_dato != valor_condicion
        elif operador == 'lessThan':
            return valor_dato < valor_condicion
        elif operador == 'lessOrEqual':
            return valor_dato <= valor_condicion
        elif operador == 'greaterThan':
            return valor_dato > valor_condicion
        elif operador == 'greaterOrEqual':
            return valor_dato >= valor_condicion
    
    return False

def cargar_pmml(nombre_archivo):
    """Cargar y procesar archivo PMML"""
    global pmml_cargado, modelo_info, campos_entrada, campo_target, archivo_pmml, modelo_pypmml, arbol_decision
    
    try:
        print(f"🔍 Cargando PMML: {nombre_archivo}")
        
        # Resetear variables
        pmml_cargado = False
        modelo_info = {}
        campos_entrada = {}
        campo_target = ""
        modelo_pypmml = None
        arbol_decision = None
        
        # Intentar cargar con pypmml primero
        if PYPMML_DISPONIBLE:
            try:
                modelo_pypmml = PMMLModel.load(nombre_archivo)
                print("✅ Modelo cargado con pypmml")
            except Exception as e:
                print(f"⚠️ Error con pypmml: {e}")
                modelo_pypmml = None
        
        # Parsear XML
        tree = ET.parse(nombre_archivo)
        root = tree.getroot()
        
        if not ('PMML' in root.tag or root.tag == 'PMML'):
            return False, "El archivo no es un PMML válido"
        
        namespace = detectar_namespace(root)
        
        # Extraer información
        extraer_info_modelo(root, namespace)
        extraer_campos_datos(root, namespace)
        campo_target = detectar_campo_target(root, namespace)
        
        # Para TreeModel, extraer estructura
        if modelo_info.get('tipo_modelo') == 'TreeModel':
            extraer_estructura_arbol(root, namespace)
        
        pmml_cargado = True
        archivo_pmml = nombre_archivo
        
        print(f"✅ PMML cargado exitosamente")
        print(f"📊 Campos: {len(campos_entrada)}")
        print(f"🎯 Target: {campo_target}")
        return True, "PMML cargado exitosamente"
        
    except Exception as e:
        error_msg = f"Error cargando PMML: {str(e)}"
        print(f"❌ {error_msg}")
        print(f"🔍 Traceback: {traceback.format_exc()}")
        return False, error_msg

def extraer_info_modelo(root, namespace=''):
    """Extraer información básica del modelo"""
    global modelo_info
    
    try:
        print("🔍 Extrayendo información del modelo...")
        
        # Header
        headers = buscar_elemento_flexible(root, 'Header', namespace)
        if headers:
            header = headers[0]
            apps = buscar_elemento_flexible(header, 'Application', namespace)
            if apps:
                app = apps[0]
                modelo_info['aplicacion'] = app.get('name', 'No especificado')
                modelo_info['version'] = app.get('version', 'No especificado')
        
        # DataDictionary
        data_dicts = buscar_elemento_flexible(root, 'DataDictionary', namespace)
        if data_dicts:
            modelo_info['num_campos'] = data_dicts[0].get('numberOfFields', '0')
        
        # Tipo de modelo
        tipos_modelo = [
            'TreeModel', 'RegressionModel', 'NeuralNetwork', 
            'SupportVectorMachineModel', 'ClusteringModel',
            'NaiveBayesModel', 'AssociationModel', 'Scorecard'
        ]
        
        for tipo_modelo in tipos_modelo:
            modelos = buscar_elemento_flexible(root, tipo_modelo, namespace)
            if modelos:
                modelo = modelos[0]
                modelo_info['tipo_modelo'] = tipo_modelo
                modelo_info['nombre_modelo'] = modelo.get('modelName', 'No especificado')
                modelo_info['funcion'] = modelo.get('functionName', 'No especificado')
                modelo_info['algoritmo'] = modelo.get('algorithmName', 'No especificado')
                print(f"✅ Modelo detectado: {tipo_modelo}")
                break
        
        print(f"📊 Info del modelo: {modelo_info}")
        
    except Exception as e:
        print(f"❌ Error extrayendo info del modelo: {e}")
        modelo_info['error'] = str(e)

def extraer_campos_datos(root, namespace=''):
    """Extraer campos de entrada del PMML"""
    global campos_entrada
    
    try:
        print("🔍 Iniciando extracción de campos...")
        
        data_dicts = buscar_elemento_flexible(root, 'DataDictionary', namespace)
        if not data_dicts:
            print("❌ No se encontró DataDictionary")
            return
        
        data_dict = data_dicts[0]
        data_fields = buscar_elemento_flexible(data_dict, 'DataField', namespace)
        
        if not data_fields:
            data_fields = buscar_elemento_flexible(root, 'DataField', namespace)
        
        if not data_fields:
            print("❌ No se encontraron DataFields")
            return
        
        print(f"📋 Procesando {len(data_fields)} DataFields...")
        
        for i, campo in enumerate(data_fields):
            nombre = campo.get('name')
            if not nombre:
                continue
            
            tipo_dato = campo.get('dataType', 'string')
            tipo_op = campo.get('optype', 'categorical')
            
            print(f"📝 Campo {i+1}: {nombre} ({tipo_dato}, {tipo_op})")
            
            # Valores categóricos
            valores = buscar_elemento_flexible(campo, 'Value', namespace)
            categorias = []
            if valores:
                categorias = [v.get('value') for v in valores if v.get('value')]
                print(f"   📋 Categorías: {categorias}")
            
            # Intervalos
            intervalos = buscar_elemento_flexible(campo, 'Interval', namespace)
            rango = None
            if intervalos:
                intervalo = intervalos[0]
                min_val = intervalo.get('leftMargin')
                max_val = intervalo.get('rightMargin')
                if min_val or max_val:
                    rango = (min_val, max_val)
                    print(f"   📊 Rango: {rango}")
            
            campos_entrada[nombre] = {
                'tipo_dato': tipo_dato,
                'tipo_operacional': tipo_op,
                'categorias': categorias,
                'rango': rango
            }
        
        print(f"✅ Extracción completada: {len(campos_entrada)} campos")
        
    except Exception as e:
        print(f"❌ Error en extracción de campos: {e}")

def hacer_prediccion_pypmml(datos_entrada):
    """Hacer predicción usando pypmml"""
    try:
        if not modelo_pypmml:
            return None
        
        resultado = modelo_pypmml.predict(datos_entrada)
        print(f"🤖 Predicción pypmml: {resultado}")
        return resultado
    except Exception as e:
        print(f"❌ Error predicción pypmml: {e}")
        return None

def hacer_prediccion_manual(datos_entrada):
    """Predicción manual usando el árbol extraído"""
    try:
        if arbol_decision:
            # Usar el árbol de decisión extraído
            prediccion = predecir_con_arbol(datos_entrada)
            if prediccion:
                return {
                    campo_target: prediccion,
                    'metodo': 'arbol_decision_extraido',
                    'confianza': 0.9
                }
        
        # Fallback: predicción básica
        if campo_target and campo_target in campos_entrada:
            categorias = campos_entrada[campo_target].get('categorias', [])
            if categorias:
                return {
                    campo_target: categorias[0],
                    'metodo': 'prediccion_fallback',
                    'confianza': 0.1
                }
        
        return {'prediccion': 'No se pudo determinar', 'metodo': 'error'}
        
    except Exception as e:
        print(f"❌ Error en predicción manual: {e}")
        return {'error': str(e), 'metodo': 'error'}

# Rutas Flask
@app.route('/')
def index():
    """Página principal"""
    archivos_pmml = buscar_archivos_pmml()
    return render_template('pmml_generico.html', 
                         pmml_cargado=pmml_cargado,
                         modelo_info=modelo_info,
                         campos_entrada=campos_entrada,
                         campo_target=campo_target,
                         archivo_pmml=archivo_pmml,
                         archivos_disponibles=archivos_pmml,
                         pypmml_disponible=PYPMML_DISPONIBLE)

@app.route('/cargar_pmml', methods=['POST'])
def cargar_pmml_endpoint():
    """Cargar archivo PMML seleccionado"""
    archivo = request.form.get('archivo_pmml')
    
    if not archivo:
        return jsonify({'error': True, 'mensaje': 'No se seleccionó archivo'})
    
    if not os.path.exists(archivo):
        return jsonify({'error': True, 'mensaje': f'Archivo {archivo} no encontrado'})
    
    exito, mensaje = cargar_pmml(archivo)
    
    if exito:
        return jsonify({
            'error': False,
            'mensaje': mensaje,
            'modelo_info': modelo_info,
            'campos_entrada': campos_entrada,
            'campo_target': campo_target,
            'archivo_cargado': archivo
        })
    else:
        return jsonify({'error': True, 'mensaje': mensaje})

@app.route('/predecir', methods=['POST'])
def predecir():
    """Realizar predicción"""
    try:
        if not pmml_cargado:
            return jsonify({'error': True, 'mensaje': 'No hay modelo PMML cargado'})
        
        datos_entrada = {}
        
        for nombre_campo in campos_entrada:
            if nombre_campo == campo_target:
                continue
                
            valor = request.form.get(nombre_campo, '').strip()
            if not valor:
                return jsonify({'error': True, 'mensaje': f'Falta valor para: {nombre_campo}'})
            
            campo_info = campos_entrada[nombre_campo]
            try:
                if campo_info['tipo_dato'] == 'integer':
                    datos_entrada[nombre_campo] = int(valor)
                elif campo_info['tipo_dato'] == 'double':
                    datos_entrada[nombre_campo] = float(valor)
                else:
                    datos_entrada[nombre_campo] = valor
            except ValueError:
                return jsonify({'error': True, 'mensaje': f'Valor inválido para {nombre_campo}: {valor}'})
        
        print(f"📋 Datos para predicción: {datos_entrada}")
        
        # Intentar predicción con pypmml
        resultado = None
        metodo_usado = ""
        
        if PYPMML_DISPONIBLE and modelo_pypmml:
            resultado = hacer_prediccion_pypmml(datos_entrada)
            if resultado:
                metodo_usado = "pypmml (Java)"
        
        # Fallback a predicción manual
        if not resultado:
            resultado = hacer_prediccion_manual(datos_entrada)
            metodo_usado = "Parser XML con árbol extraído"
        
        return jsonify({
            'error': False,
            'resultado': resultado,
            'metodo_usado': metodo_usado,
            'datos_entrada': datos_entrada,
            'modelo_info': modelo_info,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
        
    except Exception as e:
        error_msg = f"Error en predicción: {str(e)}"
        print(f"❌ {error_msg}")
        return jsonify({
            'error': True,
            'mensaje': error_msg,
            'traceback': traceback.format_exc()
        })

@app.route('/info')
def info():
    """Información del sistema"""
    archivos_pmml = buscar_archivos_pmml()
    return jsonify({
        'sistema': 'Predictor PMML Genérico Universal',
        'version': '2.0',
        'pypmml_disponible': PYPMML_DISPONIBLE,
        'pmml_cargado': pmml_cargado,
        'archivo_actual': archivo_pmml,
        'archivos_detectados': archivos_pmml,
        'modelo_info': modelo_info,
        'campos_disponibles': list(campos_entrada.keys()),
        'campo_target': campo_target,
        'tiene_arbol_extraido': arbol_decision is not None,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

@app.route('/status')
def status():
    """Estado del sistema"""
    return jsonify({
        'estado': 'Activo',
        'pmml_cargado': pmml_cargado,
        'pypmml_disponible': PYPMML_DISPONIBLE,
        'archivo_actual': archivo_pmml,
        'num_campos': len(campos_entrada),
        'modelo_tipo': modelo_info.get('tipo_modelo', 'No detectado'),
        'campo_target': campo_target,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

@app.route('/reload')
def reload():
    """Recargar el modelo actual"""
    if archivo_pmml:
        exito, mensaje = cargar_pmml(archivo_pmml)
        return jsonify({
            'exito': exito,
            'mensaje': mensaje,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    else:
        return jsonify({
            'exito': False,
            'mensaje': 'No hay archivo PMML cargado',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

# Inicialización
print("🚀 Iniciando Predictor PMML Universal...")
print(f"🔧 pypmml disponible: {'✅' if PYPMML_DISPONIBLE else '❌'}")

# NO cargar automáticamente - esperar selección del usuario
archivos_pmml = buscar_archivos_pmml()
if archivos_pmml:
    print(f"📁 Archivos PMML encontrados: {archivos_pmml}")
    print("⏳ Esperando selección de archivo por el usuario...")
else:
    print("📁 No se encontraron archivos PMML")

print("✅ Sistema listo - Seleccione un archivo PMML para comenzar")

if __name__ == "__main__":
    print("🌐 Modo desarrollo - http://localhost:9000")
    app.run(debug=True, host='127.0.0.1', port=9000)
else:
    print("🌐 Aplicación Flask PMML Universal cargada")